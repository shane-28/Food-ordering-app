from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from dotenv import load_dotenv
import os

load_dotenv()

db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()


def create_app():
    app = Flask(__name__)

    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-key")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///food_app.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    app.config["STRIPE_SECRET_KEY"] = os.getenv("STRIPE_SECRET_KEY", "")
    app.config["STRIPE_PUBLIC_KEY"] = os.getenv("STRIPE_PUBLIC_KEY", "")

    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to continue."
    login_manager.login_message_category = "warning"

    from routes.auth import auth_bp
    from routes.menu import menu_bp
    from routes.cart import cart_bp
    from routes.order import order_bp
    from routes.payment import payment_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(menu_bp)
    app.register_blueprint(cart_bp)
    app.register_blueprint(order_bp)
    app.register_blueprint(payment_bp)

    with app.app_context():
        db.create_all()
        seed_menu_items()

    return app


def seed_menu_items():
    from models.menu import MenuItem
    if MenuItem.query.first():
        return
    items = [
        MenuItem(name="Veg Burger", description="Crispy veggie patty with lettuce and sauce", price=120.0, category="Mains", image="burger.jpg"),
        MenuItem(name="Chicken Burger", description="Grilled chicken with cheese and pickles", price=160.0, category="Mains", image="chicken_burger.jpg"),
        MenuItem(name="Margherita Pizza", description="Classic tomato sauce with mozzarella", price=250.0, category="Mains", image="pizza.jpg"),
        MenuItem(name="French Fries", description="Crispy golden fries with seasoning", price=80.0, category="Starters", image="fries.jpg"),
        MenuItem(name="Spring Rolls", description="Crunchy rolls with vegetable filling", price=90.0, category="Starters", image="spring_rolls.jpg"),
        MenuItem(name="Chocolate Brownie", description="Warm brownie with vanilla ice cream", price=110.0, category="Desserts", image="brownie.jpg"),
        MenuItem(name="Mango Shake", description="Fresh mango blended with milk", price=70.0, category="Drinks", image="mango_shake.jpg"),
        MenuItem(name="Cold Coffee", description="Chilled coffee with cream", price=80.0, category="Drinks", image="cold_coffee.jpg"),
    ]
    db.session.bulk_save_objects(items)
    db.session.commit()


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
