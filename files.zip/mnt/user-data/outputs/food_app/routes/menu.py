from flask import Blueprint, render_template, request
from models.menu import MenuItem

menu_bp = Blueprint("menu", __name__)


@menu_bp.route("/")
def index():
    categories = ["Starters", "Mains", "Desserts", "Drinks"]
    selected_category = request.args.get("category", "All")
    search_query = request.args.get("search", "").strip()

    query = MenuItem.query.filter_by(is_available=True)

    if selected_category != "All":
        query = query.filter_by(category=selected_category)

    if search_query:
        query = query.filter(MenuItem.name.ilike(f"%{search_query}%"))

    items = query.all()

    return render_template(
        "index.html",
        items=items,
        categories=categories,
        selected_category=selected_category,
        search_query=search_query
    )


@menu_bp.route("/menu")
def menu():
    return index()
