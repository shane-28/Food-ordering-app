document.addEventListener("DOMContentLoaded", function () {
    updateCartCount();
});

function updateCartCount() {
    fetch("/cart/count")
        .then(res => res.json())
        .then(data => {
            const badge = document.getElementById("cart-count");
            if (badge) {
                badge.textContent = data.count;
                badge.style.display = data.count > 0 ? "inline" : "none";
            }
        })
        .catch(() => {});
}

document.querySelectorAll("form[action*='add_to_cart']").forEach(form => {
    form.addEventListener("submit", function () {
        setTimeout(updateCartCount, 500);
    });
});
