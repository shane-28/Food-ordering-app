from flask import Blueprint, render_template, redirect, url_for, flash, request, session, jsonify
from flask_login import login_required
from models.menu import MenuItem

cart_bp = Blueprint("cart", __name__)


def get_cart():
    return session.get("cart", {})


def save_cart(cart):
    session["cart"] = cart
    session.modified = True


@cart_bp.route("/cart")
@login_required
def view_cart():
    cart = get_cart()
    cart_items = []
    total = 0

    for item_id, quantity in cart.items():
        item = MenuItem.query.get(int(item_id))
        if item:
            subtotal = item.price * quantity
            total += subtotal
            cart_items.append({
                "item": item,
                "quantity": quantity,
                "subtotal": subtotal
            })

    return render_template("cart.html", cart_items=cart_items, total=total)


@cart_bp.route("/cart/add/<int:item_id>", methods=["POST"])
@login_required
def add_to_cart(item_id):
    item = MenuItem.query.get_or_404(item_id)
    cart = get_cart()
    str_id = str(item_id)

    cart[str_id] = cart.get(str_id, 0) + 1
    save_cart(cart)

    flash(f"{item.name} added to cart!", "success")
    return redirect(request.referrer or url_for("menu.index"))


@cart_bp.route("/cart/update/<int:item_id>", methods=["POST"])
@login_required
def update_cart(item_id):
    quantity = int(request.form.get("quantity", 1))
    cart = get_cart()
    str_id = str(item_id)

    if quantity <= 0:
        cart.pop(str_id, None)
        flash("Item removed from cart.", "info")
    else:
        cart[str_id] = quantity

    save_cart(cart)
    return redirect(url_for("cart.view_cart"))


@cart_bp.route("/cart/remove/<int:item_id>", methods=["POST"])
@login_required
def remove_from_cart(item_id):
    cart = get_cart()
    cart.pop(str(item_id), None)
    save_cart(cart)
    flash("Item removed from cart.", "info")
    return redirect(url_for("cart.view_cart"))


@cart_bp.route("/cart/clear", methods=["POST"])
@login_required
def clear_cart():
    save_cart({})
    flash("Cart cleared.", "info")
    return redirect(url_for("cart.view_cart"))


@cart_bp.route("/cart/count")
def cart_count():
    cart = get_cart()
    count = sum(cart.values())
    return jsonify({"count": count})
