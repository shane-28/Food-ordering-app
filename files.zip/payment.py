from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from models.order import Order
from app import db
import stripe

payment_bp = Blueprint("payment", __name__)


@payment_bp.route("/payment/<int:order_id>")
@login_required
def pay(order_id):
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first_or_404()

    if order.payment_status == "Paid":
        flash("This order has already been paid.", "info")
        return redirect(url_for("order.track_order", order_id=order.id))

    stripe_public_key = current_app.config.get("STRIPE_PUBLIC_KEY", "")
    return render_template("payment.html", order=order, stripe_public_key=stripe_public_key)


@payment_bp.route("/payment/<int:order_id>/process", methods=["POST"])
@login_required
def process_payment(order_id):
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first_or_404()

    stripe.api_key = current_app.config.get("STRIPE_SECRET_KEY", "")
    token = request.form.get("stripeToken")

    if not token:
        flash("Payment token missing. Please try again.", "danger")
        return redirect(url_for("payment.pay", order_id=order.id))

    try:
        charge = stripe.Charge.create(
            amount=int(order.total_amount * 100),
            currency="inr",
            description=f"Food Order #{order.id}",
            source=token,
            receipt_email=current_user.email
        )

        order.payment_status = "Paid"
        order.payment_id = charge["id"]
        order.status = "Preparing"
        db.session.commit()

        flash("Payment successful! Your order is being prepared.", "success")
        return redirect(url_for("order.track_order", order_id=order.id))

    except stripe.error.CardError as e:
        flash(f"Card error: {e.user_message}", "danger")
        return redirect(url_for("payment.pay", order_id=order.id))

    except stripe.error.StripeError:
        flash("Payment failed. Please try again.", "danger")
        return redirect(url_for("payment.pay", order_id=order.id))


@payment_bp.route("/payment/<int:order_id>/cancel")
@login_required
def cancel_payment(order_id):
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first_or_404()
    order.status = "Cancelled"
    db.session.commit()
    flash("Order cancelled.", "warning")
    return redirect(url_for("order.order_history"))
