from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_required, current_user
from models.order import Order, OrderItem
from models.menu import MenuItem
from app import db

order_bp = Blueprint("order", __name__)


@order_bp.route("/checkout", methods=["GET", "POST"])
@login_required
def checkout():
    cart = session.get("cart", {})
    if not cart:
        flash("Your cart is empty.", "warning")
        return redirect(url_for("menu.index"))

    cart_items = []
    total = 0
    for item_id, quantity in cart.items():
        item = MenuItem.query.get(int(item_id))
        if item:
            subtotal = item.price * quantity
            total += subtotal
            cart_items.append({"item": item, "quantity": quantity, "subtotal": subtotal})

    if request.method == "POST":
        delivery_address = request.form.get("delivery_address", "").strip()
        if not delivery_address:
            flash("Delivery address is required.", "danger")
            return render_template("checkout.html", cart_items=cart_items, total=total)

        order = Order(
            user_id=current_user.id,
            total_amount=total,
            delivery_address=delivery_address,
            status="Placed",
            payment_status="Pending"
        )
        db.session.add(order)
        db.session.flush()

        for item_id, quantity in cart.items():
            item = MenuItem.query.get(int(item_id))
            if item:
                order_item = OrderItem(
                    order_id=order.id,
                    menu_item_id=item.id,
                    quantity=quantity,
                    price=item.price
                )
                db.session.add(order_item)

        db.session.commit()
        session["cart"] = {}
        session.modified = True
        session["pending_order_id"] = order.id

        flash("Order placed! Complete payment to confirm.", "success")
        return redirect(url_for("payment.pay", order_id=order.id))

    return render_template("checkout.html", cart_items=cart_items, total=total,
                           user_address=current_user.address)


@order_bp.route("/orders")
@login_required
def order_history():
    orders = Order.query.filter_by(user_id=current_user.id).order_by(Order.created_at.desc()).all()
    return render_template("order_history.html", orders=orders)


@order_bp.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id):
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first_or_404()
    return render_template("order_detail.html", order=order)


@order_bp.route("/orders/<int:order_id>/track")
@login_required
def track_order(order_id):
    order = Order.query.filter_by(id=order_id, user_id=current_user.id).first_or_404()
    status_flow = Order.STATUS_FLOW
    current_step = status_flow.index(order.status) if order.status in status_flow else 0
    return render_template("order_tracking.html", order=order,
                           status_flow=status_flow, current_step=current_step)
